using MetroFramework.Forms;
using $ext_safeprojectname$.Presentation.Base;

namespace $ext_safeprojectname$.Presentation.Forms;

public partial class BaseForm : MetroForm
{
    public BaseForm()
    {
        InitializeComponent();

        AppearanceManager.LoadBaseSettings(this);
    }
}

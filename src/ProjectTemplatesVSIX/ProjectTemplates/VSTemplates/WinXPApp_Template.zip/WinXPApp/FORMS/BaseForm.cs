using MetroFramework.Forms;
using $safeprojectname$.Presentation.Base;

namespace $safeprojectname$.Presentation.Forms
{
    public partial class BaseForm : MetroForm
    {
        public BaseForm()
        {
            InitializeComponent();

            AppearanceManager.LoadBaseSettings(this);
        }
    }
}

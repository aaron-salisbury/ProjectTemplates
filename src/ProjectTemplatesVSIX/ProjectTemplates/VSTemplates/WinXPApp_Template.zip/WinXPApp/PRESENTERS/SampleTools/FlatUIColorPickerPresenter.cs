using $ext_safeprojectname$.Business.Modules.Sample.ApplicationServices;
using System.Linq;
using System.Windows.Forms;
using $ext_safeprojectname$.Presentation.Base.MVP;
using $ext_safeprojectname$.Presentation.Views.SampleTools;

namespace $ext_safeprojectname$.Presentation.Presenters.SampleTools;

internal class FlatUIColorPickerPresenter : Presenter
{
    private readonly ISampleToolsService _sampleToolsService;

    private FlatUIColorPickerView _view;

    public FlatUIColorPickerPresenter(ISampleToolsService sampleToolsService)
    {
        _sampleToolsService = sampleToolsService;
    }

    internal override void Setup(UserControl view)
    {
        _view = (FlatUIColorPickerView)view;

        _view.Initialize(_sampleToolsService.GetFlatColors().ToList());
    }
}

using System.Windows.Forms;
using $ext_safeprojectname$.Presentation.Base.MVP;
using $ext_safeprojectname$.Presentation.Views.SampleTools;

namespace $ext_safeprojectname$.Presentation.Presenters.SampleTools;

internal class ToolsNavigatorPresenter : Presenter
{
    private ToolsNavigatorView _view;

    internal override void Setup(UserControl view)
    {
        _view = (ToolsNavigatorView)view;
    }
}

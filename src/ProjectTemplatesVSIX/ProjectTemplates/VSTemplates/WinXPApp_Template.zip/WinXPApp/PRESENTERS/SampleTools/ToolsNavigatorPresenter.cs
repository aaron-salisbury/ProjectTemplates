using System.Windows.Forms;
using $safeprojectname$.Presentation.Base.MVP;
using $safeprojectname$.Presentation.Views.SampleTools;

namespace $safeprojectname$.Presentation.Presenters.SampleTools
{
    internal class ToolsNavigatorPresenter : Presenter
    {
        private ToolsNavigatorView _view;

        internal override void Setup(UserControl view)
        {
            _view = (ToolsNavigatorView)view;
        }
    }
}

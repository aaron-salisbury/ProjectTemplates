using System.Windows.Forms;
using $ext_safeprojectname$.Presentation.Base.MVP;
using $ext_safeprojectname$.Presentation.Views;

namespace $ext_safeprojectname$.Presentation.Presenters;

internal class HomePresenter : Presenter
{
    private HomeView _view;

    internal override void Setup(UserControl view)
    {
        _view = (HomeView)view;

        //_view.Initialize(new HomeModel()
        //{
        //    //TODO: Use resources.
        //    IntroductionBlurb = "This is a sample application generated from Aaron Salisbury's Windows 98 App Solution Template.",
        //    LoggingBlurb = "The application shares an implementation of the pluggable and reusable Logging application block of the Microsoft Enterprise Library."
        //});
    }
}

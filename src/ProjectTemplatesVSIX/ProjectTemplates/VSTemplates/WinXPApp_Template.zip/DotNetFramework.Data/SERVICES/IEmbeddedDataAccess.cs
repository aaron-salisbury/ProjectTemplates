using $safeprojectname$.Data.Entities;
using System.Collections.Generic;

namespace $safeprojectname$.Data
{
    /// <summary>
    /// Read Embedded data.
    /// </summary>
    public interface IEmbeddedDataAccess
    {
        List<FlatColor> ReadFlatColors();
    }
}

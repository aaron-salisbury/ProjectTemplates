using $ext_safeprojectname$.Business.Modules.Sample.ApplicationServices;
using $ext_safeprojectname$.Business.Modules.Sample.DomainServices;
using $ext_safeprojectname$.Data;
using DotNetFrameworkToolkit.Modules.DataAccess.FileSystem;
using DotNetFrameworkToolkit.Modules.DependencyInjection;

namespace $ext_safeprojectname$.Business
{
    public static class Builder
    {
        /// <summary>
        /// Adds business-tier services.
        /// Dependent on <see cref="ILogger"/>.
        /// </summary>
        /// <returns>A reference to this instance after the operation has completed.</returns>
        public static IServiceCollection BuildBusinessServices(IServiceCollection services)
        {
            // Necessary infrastructure.
            ServiceCollectionExtensions.AddScoped<IFileSystemAccess, FileSystemAccess>(services);
            ServiceCollectionExtensions.AddScoped<IEmbeddedDataAccess, EmbeddedDataAccess>(services);

            // Internal business domain logic.
            ServiceCollectionExtensions.AddScoped<FlatUIColorProvider, FlatUIColorProvider>(services);
            ServiceCollectionExtensions.AddScoped<LineSorter, LineSorter>(services);
            ServiceCollectionExtensions.AddScoped<UUIDGenerator, UUIDGenerator>(services);

            // Orchestrated public-facing (application) services.
            ServiceCollectionExtensions.AddScoped<ISampleToolsService, SampleToolsService>(services);

            return services;
        }
    }
}

using $ext_safeprojectname$.Business.Modules.Sample.DTOs;
using System.Collections.Generic;
using static $ext_safeprojectname$.Business.Modules.Sample.DomainServices.LineSorter;

namespace $ext_safeprojectname$.Business.Modules.Sample.ApplicationServices
{
    public interface ISampleToolsService
    {
        IEnumerable<FlatColorDto> GetFlatColors();

        string InitializeLineSorting(SortTypes _selectedSortType, string textToSort);

        string InitializeGUIDGeneration(bool shouldCapitalize = true);
    }
}

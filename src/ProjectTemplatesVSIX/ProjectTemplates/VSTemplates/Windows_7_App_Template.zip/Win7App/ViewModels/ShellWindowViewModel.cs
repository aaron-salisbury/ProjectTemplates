﻿using FirstFloor.ModernUI.Presentation;
using GalaSoft.MvvmLight;
using $ext_safeprojectname$.Core.Base;
using $safeprojectname$.Properties;
using System;
using System.ComponentModel;

namespace $safeprojectname$.ViewModels
{
    public class ShellWindowViewModel : ViewModelBase
    {
        private static readonly Link _settingsUri = new Link { DisplayName = "Settings", Source = new Uri("/Views/Settings.xaml", UriKind.Relative) };

        public AppLogger AppLogger { get; set; }

        private string _helpURL;
        public string HelpURL
        {
            get { return _helpURL; }
            set
            {
                Set(ref _helpURL, value);
                HelpUri = new Link { DisplayName = "Help", Source = new Uri(HelpURL, UriKind.Absolute) };
            }
        }

        private Link _helpUri;
        public Link HelpUri
        {
            get { return _helpUri; }
            set
            {
                Set(ref _helpUri, value);
                TitleLinks = new LinkCollection { _settingsUri, HelpUri };
            }
        }

        private LinkCollection _titleLinks = new LinkCollection();
        public LinkCollection TitleLinks
        {
            get { return _titleLinks; }
            set { Set(ref _titleLinks, value); }
        }

        public string Title
        {
            get { return Settings.Default.ApplicationFriendlyName; }
        }

        public ShellWindowViewModel()
        {
            AppLogger = new AppLogger();

            HelpURL = Properties.Settings.Default.DefaultHelpURL;

            System.Windows.Application.Current.MainWindow.Closing += new CancelEventHandler(ShellWindow_Closing);
        }

        void ShellWindow_Closing(object sender, CancelEventArgs e)
        {
            GalaSoft.MvvmLight.Threading.DispatcherHelper.Reset();
        }
    }
}

using $ext_safeprojectname$.Modules.Sample.ApplicationServices;
using System.Linq;
using System.Windows.Forms;
using $safeprojectname$.Presentation.Base.MVP;
using $safeprojectname$.Presentation.Views.SampleTools;
using static System.Windows.Forms.Control;

namespace $safeprojectname$.Presentation.Presenters.SampleTools
{
    internal class FlatUIColorPickerPresenter : Presenter
    {
        private readonly ISampleToolsService _sampleToolsService;

        private FlatUIColorPickerView _view;

        public FlatUIColorPickerPresenter(Navigator navigator, ISampleToolsService sampleToolsService) : base(navigator)
        {
            _sampleToolsService = sampleToolsService;
        }

        internal override void Display(Control view, ControlCollection window)
        {
            _view = (FlatUIColorPickerView)view;

            _view.Initialize(_sampleToolsService.GetFlatColors().ToList());

            window.Clear();
            window.Add(_view);
        }
    }
}

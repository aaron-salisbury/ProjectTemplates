using DotNetFrameworkToolkit.Core;
using DotNetFrameworkToolkit.Core.Extensions;
using DotNetFrameworkToolkit.Modules.DataAccess.FileSystem;
using DotNetFrameworkToolkit.Modules.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using $ext_safeprojectname$.Presentation.Base.MVP;
using $ext_safeprojectname$.Presentation.Views;
using static System.Windows.Forms.Control;

namespace $ext_safeprojectname$.Presentation.Presenters;

internal class LogsPresenter : Presenter
{
    private readonly InMemorySinkPNP _logSource;
    private readonly ILogger _logger;
    private readonly IFileSystemAccess _fileSystemAccess;
    private List<string> _errorLogs;
    private LogsView _view;

    public LogsPresenter(Navigator navigator, InMemorySinkPNP logSource, ILogger logger, IFileSystemAccess fileSystemAccess) : base(navigator)
    {
        _logSource = logSource;
        _logger = logger;
        _fileSystemAccess = fileSystemAccess;
    }

    internal override void Display(Control view, ControlCollection window)
    {
        _view = (LogsView)view;

        _view.DownloadCommand += View_DownloadCommand;

        RefreshErrors();
        _logSource.LogEmitted += LogSource_LogEmitted; // So the logs view refreshes with new errors while the logs view is in focus.

        window.Clear();
        window.Add(_view);
    }

    internal override void Dismiss()
    {
        if (_view != null)
        {
            _view.DownloadCommand -= View_DownloadCommand;
        }

        if (_logSource != null)
        {
            _logSource.LogEmitted -= LogSource_LogEmitted;
        }
    }

    private void RefreshErrors()
    {
        if (_view != null)
        {
            _errorLogs = new List<string>(_logSource.Logs);

            _view.UpdateLogs(_errorLogs);
        }
    }

    private void LogSource_LogEmitted(object sender, LogEmitEventArgs e)
    {
        //TODO: Right now the logs view simply joins all the messages into one long sting,
        //  but could use the data off of LogEmitEventArgs to build a list box or data grid.
        RefreshErrors();
    }

    private void View_DownloadCommand(object sender, EventArgs e)
    {
        ProcessResult<string> appDirectoryResult = _fileSystemAccess.GetAppDirectoryPath();
        if (!appDirectoryResult.IsSuccessful)
        {
            LoggerExtensions.LogError(_logger, appDirectoryResult.Error, "Could not get app directory path to write logs to.");
            return;
        }

        string appDirectoryPath = appDirectoryResult.Value;
        string logsPath = Path.Combine(appDirectoryPath, "Logs");
        string fileName = $"Logs_{DateTimeExtensions.ToTimeStamp(DateTime.Now)}.txt";

        ProcessResult<bool> writeResult = _fileSystemAccess.WriteFile(_errorLogs, fileName, logsPath);
        if (writeResult.IsSuccessful)
        {
            LoggerExtensions.LogInformation(_logger, "Wrote log file '{0}' to '{1}'", fileName, logsPath);

            try
            {
                Process.Start(new ProcessStartInfo(Path.Combine(logsPath, fileName))
                {
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                LoggerExtensions.LogError(_logger, ex, "Failed to open file.");
            }
        }
    }
}

using System;

namespace $safeprojectname$.Presentation.Models
{
    internal class HomeModel
    {
        public string IntroductionBlurb { get; set; }
        public string DesignBlurb { get; set; }
        public string LoggingBlurb { get; set; }
        public string UseBlurb { get; set; }
    }
}

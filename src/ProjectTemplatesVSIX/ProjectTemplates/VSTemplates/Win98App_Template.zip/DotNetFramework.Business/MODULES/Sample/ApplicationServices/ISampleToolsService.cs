using $safeprojectname$.Business.Modules.Sample.DTOs;
using System.Collections.Generic;
using static $safeprojectname$.Business.Modules.Sample.DomainServices.LineSorter;

namespace $safeprojectname$.Business.Modules.Sample.ApplicationServices
{
    public interface ISampleToolsService
    {
        IEnumerable<FlatColorDto> GetFlatColors();

        string InitializeLineSorting(SortTypes _selectedSortType, string textToSort);

        string InitializeGUIDGeneration(bool shouldCapitalize = true);
    }
}

using $ext_safeprojectname$.Data.Entities;
using System.Collections.Generic;

namespace $ext_safeprojectname$.Data
{
    /// <summary>
    /// Read Embedded data.
    /// </summary>
    public interface IEmbeddedDataAccess
    {
        List<FlatColor> ReadFlatColors();
    }
}

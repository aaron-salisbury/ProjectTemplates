using System.Windows.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class LogsView : UserControl
{
    public LogsView()
    {
        InitializeComponent();
        this.SetDataContext((System.Windows.Application.Current as App)?.Services);
    }
}

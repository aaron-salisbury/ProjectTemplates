using System.Windows.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class HomeView : UserControl
{
    public HomeView()
    {
        InitializeComponent();
        this.SetDataContext((System.Windows.Application.Current as App)?.Services);
    }
}

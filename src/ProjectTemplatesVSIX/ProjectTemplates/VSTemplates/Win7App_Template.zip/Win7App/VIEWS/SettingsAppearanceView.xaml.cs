using System.Windows.Controls;
using $safeprojectname$.Presentation.Base.Extensions;

namespace $safeprojectname$.Presentation.Views
{
    public partial class SettingsAppearanceView : UserControl
    {
        public SettingsAppearanceView()
        {
            InitializeComponent();
            this.SetDataContext((System.Windows.Application.Current as App)?.Services);
        }
    }
}

using DotNetFrameworkToolkit.Modules.DependencyInjection;
using System.Windows.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class SettingsAppearanceView : UserControl
{
    public SettingsAppearanceView()
    {
        InitializeComponent();
        this.SetDataContext(Ioc.Default);
    }
}

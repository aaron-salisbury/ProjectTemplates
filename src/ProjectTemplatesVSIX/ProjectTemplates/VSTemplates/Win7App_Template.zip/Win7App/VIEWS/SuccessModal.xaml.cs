using System.Windows.Controls;

namespace $safeprojectname$.Presentation.Views
{
    public partial class SuccessModal : UserControl
    {
        public SuccessModal()
        {
            InitializeComponent();
        }
    }
}

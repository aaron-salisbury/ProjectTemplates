using System.Windows.Controls;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class SuccessModal : UserControl
{
    public SuccessModal()
    {
        InitializeComponent();
    }
}

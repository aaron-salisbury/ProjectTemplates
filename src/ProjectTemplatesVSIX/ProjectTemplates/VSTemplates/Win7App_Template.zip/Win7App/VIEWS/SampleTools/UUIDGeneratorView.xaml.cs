using DotNetFrameworkToolkit.Modules.DependencyInjection;
using System.Windows.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;

namespace $ext_safeprojectname$.Presentation.Views.SampleTools;

public partial class UUIDGeneratorView : UserControl
{
    public UUIDGeneratorView()
    {
        InitializeComponent();
        this.SetDataContext(Ioc.Default);
    }
}

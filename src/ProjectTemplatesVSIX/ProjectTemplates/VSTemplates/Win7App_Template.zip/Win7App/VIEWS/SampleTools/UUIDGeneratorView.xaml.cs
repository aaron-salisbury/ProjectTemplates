using System.Windows.Controls;
using $safeprojectname$.Presentation.Base.Extensions;

namespace $safeprojectname$.Presentation.Views.SampleTools
{
    public partial class UUIDGeneratorView : UserControl
    {
        public UUIDGeneratorView()
        {
            InitializeComponent();
            this.SetDataContext((System.Windows.Application.Current as App)?.Services);
        }
    }
}

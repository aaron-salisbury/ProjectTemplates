using System.Windows.Controls;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class Settings : UserControl
{
    public Settings()
    {
        InitializeComponent();
    }
}

using System.Windows.Controls;

namespace $safeprojectname$.Presentation.Views
{
    public partial class Settings : UserControl
    {
        public Settings()
        {
            InitializeComponent();
        }
    }
}

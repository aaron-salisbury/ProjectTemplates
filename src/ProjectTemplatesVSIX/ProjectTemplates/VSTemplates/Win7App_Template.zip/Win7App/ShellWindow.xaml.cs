using FirstFloor.ModernUI.Presentation;
using FirstFloor.ModernUI.Windows.Controls;
using $safeprojectname$.Presentation.Base.Extensions;
using $safeprojectname$.Presentation.ViewModels;

namespace $safeprojectname$.Presentation
{
    public partial class ShellWindow : ModernWindow
    {
        public ShellWindow()
        {
            InitializeComponent();
            this.DataContext = new ShellWindowViewModel();
            AppearanceManager.Current.LoadAppearancesFromSettings(Properties.Settings.Default);
        }
    }
}

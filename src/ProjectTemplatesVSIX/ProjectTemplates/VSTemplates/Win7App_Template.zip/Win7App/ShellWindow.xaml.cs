using FirstFloor.ModernUI.Presentation;
using FirstFloor.ModernUI.Windows.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;
using $ext_safeprojectname$.Presentation.ViewModels;

namespace $ext_safeprojectname$.Presentation;

public partial class ShellWindow : ModernWindow
{
    public ShellWindow()
    {
        InitializeComponent();
        this.DataContext = new ShellWindowViewModel();
        AppearanceManager.Current.LoadAppearancesFromSettings(Properties.Settings.Default);
    }
}

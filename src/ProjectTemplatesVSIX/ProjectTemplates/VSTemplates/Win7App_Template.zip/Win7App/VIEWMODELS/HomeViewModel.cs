using $safeprojectname$.Presentation.Base;
using $safeprojectname$.Presentation.Properties;

namespace $safeprojectname$.Presentation.ViewModels;

public class HomeViewModel : BaseViewModel
{
    public string Title
    {
        get { return Settings.Default.ApplicationFriendlyName; }
    }
}

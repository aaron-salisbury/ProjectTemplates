using $ext_safeprojectname$.Presentation.Base;
using $ext_safeprojectname$.Presentation.Properties;

namespace $ext_safeprojectname$.Presentation.ViewModels;

public class HomeViewModel : BaseViewModel
{
    public string Title
    {
        get { return Settings.Default.ApplicationFriendlyName; }
    }
}

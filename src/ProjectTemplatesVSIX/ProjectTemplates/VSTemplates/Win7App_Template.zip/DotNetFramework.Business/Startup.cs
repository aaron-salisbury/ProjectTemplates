using $safeprojectname$.Business.Modules.Sample.ApplicationServices;
using $safeprojectname$.Business.Modules.Sample.DomainServices;
using $safeprojectname$.Data;
using DotNetFrameworkToolkit.Modules.DataAccess.FileSystem;
using DotNetFrameworkToolkit.Modules.DependencyInjection;

namespace $safeprojectname$.Business
{
    public static class Startup
    {
        /// <summary>
        /// Adds business-tier services.
        /// Dependent on <see cref="ILogger"/>.
        /// </summary>
        /// <returns>A reference to this instance after the operation has completed.</returns>
        public static IServiceCollection AddBusinessServices(this IServiceCollection services)
        {
            // Necessary infrastructure.
            services.AddScoped<IFileSystemAccess, FileSystemAccess>()
                .AddScoped<IEmbeddedDataAccess, EmbeddedDataAccess>();

            // Internal business domain logic.
            services.AddScoped<FlatUIColorProvider, FlatUIColorProvider>()
                .AddScoped<LineSorter, LineSorter>()
                .AddScoped<UUIDGenerator, UUIDGenerator>();

            // Orchestrated public-facing (application) services.
            services.AddScoped<ISampleToolsService, SampleToolsService>();

            return services;
        }
    }
}

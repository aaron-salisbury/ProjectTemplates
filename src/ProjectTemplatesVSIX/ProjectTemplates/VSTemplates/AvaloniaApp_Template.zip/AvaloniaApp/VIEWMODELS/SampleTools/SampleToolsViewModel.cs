using RunnethOverStudio.AppToolkit.Presentation.MVVM;

namespace $ext_safeprojectname$.Presentation.ViewModels;

public partial class SampleToolsViewModel : BaseViewModel
{
}

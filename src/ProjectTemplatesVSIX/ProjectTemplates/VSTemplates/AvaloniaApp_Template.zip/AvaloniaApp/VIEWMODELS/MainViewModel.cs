using RunnethOverStudio.AppToolkit.Presentation.MVVM;

namespace $ext_safeprojectname$.Presentation.ViewModels;

internal class MainViewModel : BaseViewModel
{
}

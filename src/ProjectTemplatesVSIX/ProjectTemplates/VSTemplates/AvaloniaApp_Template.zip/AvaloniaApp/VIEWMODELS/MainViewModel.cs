using RunnethOverStudio.AppToolkit.Presentation.MVVM;

namespace $safeprojectname$.Presentation.ViewModels;

internal class MainViewModel : BaseViewModel
{
}

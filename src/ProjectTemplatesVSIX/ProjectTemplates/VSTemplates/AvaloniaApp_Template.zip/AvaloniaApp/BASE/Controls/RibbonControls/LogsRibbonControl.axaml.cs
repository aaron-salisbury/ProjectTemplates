using $ext_safeprojectname$.Presentation.Base.Controls.RibbonControls;
using $ext_safeprojectname$.Presentation.ViewModels;
using CommunityToolkit.Mvvm.DependencyInjection;

namespace $ext_safeprojectname$.Presentation.Base.Controls;

public partial class LogsRibbonControl : BaseRibbonControl
{
    public LogsRibbonControl()
    {
        InitializeComponent();
        this.DataContext = Ioc.Default.GetService(typeof(LogsViewModel));
    }
}

using Avalonia;
using $ext_safeprojectname$.Presentation.Base.Controls.RibbonControls;
using $ext_safeprojectname$.Presentation.ViewModels;

namespace $ext_safeprojectname$.Presentation.Base.Controls;

public partial class LogsRibbonControl : BaseRibbonControl
{
    public LogsRibbonControl()
    {
        InitializeComponent();
        this.DataContext = (Application.Current as App)?.Services.GetService(typeof(LogsViewModel));
    }
}

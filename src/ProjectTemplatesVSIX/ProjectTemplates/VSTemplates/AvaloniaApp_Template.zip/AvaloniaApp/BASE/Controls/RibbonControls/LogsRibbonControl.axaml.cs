using Avalonia;
using $safeprojectname$.Presentation.Base.Controls.RibbonControls;
using $safeprojectname$.Presentation.ViewModels;

namespace $safeprojectname$.Presentation.Base.Controls;

public partial class LogsRibbonControl : BaseRibbonControl
{
    public LogsRibbonControl()
    {
        InitializeComponent();
        this.DataContext = (Application.Current as App)?.Services.GetService(typeof(LogsViewModel));
    }
}

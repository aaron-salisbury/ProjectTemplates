using Avalonia.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;
using CommunityToolkit.Mvvm.DependencyInjection;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
        this.SetDataContext(Ioc.Default);
    }
}

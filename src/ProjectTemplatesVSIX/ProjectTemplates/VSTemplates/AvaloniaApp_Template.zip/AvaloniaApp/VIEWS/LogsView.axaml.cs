using Avalonia;
using Avalonia.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class LogsView : UserControl
{
    public LogsView()
    {
        InitializeComponent();
        this.SetDataContext((Application.Current as App)?.Services);
    }
}
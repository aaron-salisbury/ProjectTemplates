using Avalonia.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;
using CommunityToolkit.Mvvm.DependencyInjection;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class SampleToolsView : UserControl
{
    public SampleToolsView()
    {
        InitializeComponent();
        this.SetDataContext(Ioc.Default);
    }
}
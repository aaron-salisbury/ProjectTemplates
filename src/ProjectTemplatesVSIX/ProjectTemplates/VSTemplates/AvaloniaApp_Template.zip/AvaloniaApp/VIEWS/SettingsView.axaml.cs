using Avalonia;
using Avalonia.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class SettingsView : UserControl
{
    public SettingsView()
    {
        InitializeComponent();
        this.SetDataContext((Application.Current as App)?.Services);
    }
}
using Avalonia.Controls;
using $ext_safeprojectname$.Presentation.Base.Extensions;
using CommunityToolkit.Mvvm.DependencyInjection;

namespace $ext_safeprojectname$.Presentation.Views;

public partial class SettingsView : UserControl
{
    public SettingsView()
    {
        InitializeComponent();
        this.SetDataContext(Ioc.Default);
    }
}
using System;

namespace $ext_safeprojectname$.Presentation.Models;

public record MenuPaneItemTemplate(Type ModelType, string IconKey, string Label);

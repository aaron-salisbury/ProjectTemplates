using System;

namespace $ext_safeprojectname$.Business.Modules.Sample.Events;

public class TextSorted : EventArgs
{
    public required string? SortedText { get; init; }
}

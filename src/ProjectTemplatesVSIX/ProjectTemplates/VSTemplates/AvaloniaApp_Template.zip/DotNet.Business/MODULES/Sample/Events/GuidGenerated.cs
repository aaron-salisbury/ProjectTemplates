using System;

namespace $safeprojectname$.Business.Modules.Sample.Events
{
    public class GuidGenerated : EventArgs
    {
        public required string UUID { get; init; }
    }
}

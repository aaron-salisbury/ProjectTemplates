using System;

namespace $ext_safeprojectname$.Data.Entities;

public record FlatColor
{
    public required string Name { get; init; }
    public required string Hex { get; init; }
}

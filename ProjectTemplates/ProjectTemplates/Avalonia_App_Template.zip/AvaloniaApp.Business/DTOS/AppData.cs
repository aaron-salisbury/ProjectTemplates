﻿using $ext_safeprojectname$.Data.Attributes;

namespace $safeprojectname$.DTOs
{
    [Serializable, BaseName("$safeprojectname$")]
    internal class AppData
    {
        public string? Version { get; set; }
    }
}

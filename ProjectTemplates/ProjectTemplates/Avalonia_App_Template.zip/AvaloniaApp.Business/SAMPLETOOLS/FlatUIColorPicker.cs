﻿using $safeprojectname$.Base;
using $ext_safeprojectname$.Data;
using $ext_safeprojectname$.Data.Domains;

namespace $safeprojectname$.SampleTools
{
    public class FlatUIColorPicker : ObservableModel
    {
        public static IEnumerable<FlatColor> FlatColors { get; set; } = Access.ReadFlatColors();
    }
}

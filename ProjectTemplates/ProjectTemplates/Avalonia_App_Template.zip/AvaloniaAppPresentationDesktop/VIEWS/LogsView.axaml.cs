using Avalonia;
using Avalonia.Controls;
using $safeprojectname$.Base.Extensions;

namespace $safeprojectname$.Views;

public partial class LogsView : UserControl
{
    public LogsView()
    {
        InitializeComponent();
        this.SetDataContext((Application.Current as App)?.Services);
    }
}
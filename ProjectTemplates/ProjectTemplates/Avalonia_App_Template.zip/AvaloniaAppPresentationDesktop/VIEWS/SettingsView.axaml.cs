using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using $safeprojectname$.Base;
using $safeprojectname$.Base.Extensions;
using $safeprojectname$.ViewModels;

namespace $safeprojectname$.Views;

public partial class SettingsView : UserControl
{
    public SettingsView()
    {
        InitializeComponent();
        this.SetDataContext((Application.Current as App)?.Services);
    }

    private void PrivacyBtn_Click(object? sender, RoutedEventArgs a)
    {
        if (DataContext is SettingsViewModel viewModel)
        {
            Browser.Open(viewModel.PrivacyURL);
        }
    }

    private void IssuesBtn_Click(object? sender, RoutedEventArgs a)
    {
        if (DataContext is SettingsViewModel viewModel)
        {
            Browser.Open(viewModel.IssuesURL);
        }
    }
}
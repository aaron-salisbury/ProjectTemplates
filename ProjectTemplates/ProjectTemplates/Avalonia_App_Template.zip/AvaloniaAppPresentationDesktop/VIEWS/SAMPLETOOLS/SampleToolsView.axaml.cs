using Avalonia;
using Avalonia.Controls;
using $safeprojectname$.Base.Extensions;

namespace $safeprojectname$.Views;

public partial class SampleToolsView : UserControl
{
    public SampleToolsView()
    {
        InitializeComponent();
        this.SetDataContext((Application.Current as App)?.Services);
    }
}
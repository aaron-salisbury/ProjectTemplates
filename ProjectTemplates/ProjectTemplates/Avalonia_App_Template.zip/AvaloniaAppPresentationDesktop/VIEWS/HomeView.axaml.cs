using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using $safeprojectname$.Base;
using $safeprojectname$.Base.Extensions;
using $safeprojectname$.ViewModels;

namespace $safeprojectname$.Views;

public partial class HomeView : UserControl
{
    public HomeView()
    {
        InitializeComponent();
        this.SetDataContext((Application.Current as App)?.Services);
    }

    private void LicenseBtn_Click(object? sender, RoutedEventArgs a)
    {
        if (DataContext is HomeViewModel viewModel)
        {
            Browser.Open(viewModel.LicenseURL);
        }
    }
}
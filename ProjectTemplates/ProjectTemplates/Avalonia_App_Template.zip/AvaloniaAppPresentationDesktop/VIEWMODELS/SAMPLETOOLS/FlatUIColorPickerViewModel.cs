﻿using $ext_safeprojectname$.Business.Modules.Sample.ApplicationServices;
using $ext_safeprojectname$.Business.Modules.Sample.DTOs;
using $safeprojectname$.Base;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$.ViewModels;

public partial class FlatUIColorPickerViewModel : BaseViewModel
{
    public List<FlatColorDto> FlatColors { get; set; }

    public FlatUIColorPickerViewModel(ISampleToolsService sampleToolsService)
    {
        FlatColors = sampleToolsService.GetFlatColors().ToList();
    }
}

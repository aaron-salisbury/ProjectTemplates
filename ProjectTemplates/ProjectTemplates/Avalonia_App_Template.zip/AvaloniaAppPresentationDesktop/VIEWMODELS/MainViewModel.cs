﻿using $safeprojectname$.Base;

namespace $safeprojectname$.ViewModels;

internal class MainViewModel : BaseViewModel
{
}

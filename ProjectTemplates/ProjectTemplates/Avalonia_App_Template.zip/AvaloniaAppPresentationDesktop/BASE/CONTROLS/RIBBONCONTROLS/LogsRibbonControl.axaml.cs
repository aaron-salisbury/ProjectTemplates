using Avalonia;
using Avalonia.Controls;
using $safeprojectname$.ViewModels;

namespace $safeprojectname$.Base.Controls;

public partial class LogsRibbonControl : UserControl
{
    public LogsRibbonControl()
    {
        InitializeComponent();
        this.DataContext = (Application.Current as App)?.Services.GetService(typeof(LogsViewModel));
    }
}

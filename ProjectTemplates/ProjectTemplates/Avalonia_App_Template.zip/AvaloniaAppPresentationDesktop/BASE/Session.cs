﻿using $ext_safeprojectname$.Business;

namespace $safeprojectname$.Base;

public class Session : ISessionValueProvider
{
    private int? _endUser;

    public int? GetUserID()
    {
        return _endUser;
    }

    public void SetUserID(int id)
    {
        _endUser = id;
    }
}

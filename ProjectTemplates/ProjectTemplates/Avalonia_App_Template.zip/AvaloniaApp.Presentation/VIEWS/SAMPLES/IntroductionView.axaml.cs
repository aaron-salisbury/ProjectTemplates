using Avalonia.Controls;
using Avalonia.Interactivity;
using $safeprojectname$.Base;
using $safeprojectname$.Base.Extensions;
using $safeprojectname$.ViewModels;

namespace $safeprojectname$.Views
{
    public partial class IntroductionView : UserControl
    {
        public IntroductionView()
        {
            InitializeComponent();
            this.SetDataContext(App.Current?.Services);
        }

        private void LiceseBtn_OnClick(object? sender, RoutedEventArgs a)
        {
            if (DataContext is IntroductionViewModel viewModel)
            {
                Browser.Open(viewModel.LicenseURL);
            }
        }
    }
}

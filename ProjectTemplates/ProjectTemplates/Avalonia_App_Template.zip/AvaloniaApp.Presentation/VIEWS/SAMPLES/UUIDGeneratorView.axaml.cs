using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using $safeprojectname$.Base.Extensions;
using $safeprojectname$.ViewModels;

namespace $safeprojectname$.Views
{
    public partial class UUIDGeneratorView : UserControl
    {
        public UUIDGeneratorView()
        {
            InitializeComponent();
            this.SetDataContext(App.Current?.Services);
        }

        private async void CopyBtn_OnClick(object? sender, RoutedEventArgs e)
        {
            if (DataContext is UUIDGeneratorViewModel viewModel && viewModel.UUID != null)
            {
                var clipboard = TopLevel.GetTopLevel(this)?.Clipboard;

                if (clipboard != null)
                {
                    var dataObject = new DataObject();
                    dataObject.Set(DataFormats.Text, viewModel.UUID);

                    await clipboard.SetDataObjectAsync(dataObject);
                }
            }
        }
    }
}

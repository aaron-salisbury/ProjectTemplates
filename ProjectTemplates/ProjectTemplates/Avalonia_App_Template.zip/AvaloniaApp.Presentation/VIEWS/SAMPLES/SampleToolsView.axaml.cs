using Avalonia.Controls;

namespace $safeprojectname$.Views
{
    public partial class SampleToolsView : UserControl
    {
        public SampleToolsView()
        {
            InitializeComponent();
        }
    }
}

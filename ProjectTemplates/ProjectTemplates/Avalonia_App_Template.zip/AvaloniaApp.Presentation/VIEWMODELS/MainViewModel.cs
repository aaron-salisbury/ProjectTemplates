﻿using $safeprojectname$.Base;
using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.ViewModels;

public partial class MainViewModel : BaseViewModel
{

}

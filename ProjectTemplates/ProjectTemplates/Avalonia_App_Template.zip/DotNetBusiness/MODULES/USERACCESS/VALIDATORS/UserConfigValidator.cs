﻿using $safeprojectname$.Modules.UserAccess.DTOs;
using FluentValidation;

namespace $safeprojectname$.Modules.Trading.Validators
{
    public class UserConfigValidator : AbstractValidator<UserConfigDto>
    {
        public UserConfigValidator()
        {
            RuleFor(dto => dto.Email).EmailAddress();
        }
    }
}

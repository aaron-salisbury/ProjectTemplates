﻿using $safeprojectname$.Modules.UserAccess.DTOs;
using FluentValidation;

namespace $safeprojectname$.Modules.Trading.Validators;

public class EndUserValidator : AbstractValidator<EndUserDto>
{
    public EndUserValidator()
    {
        RuleFor(dto => dto.UserConfig).SetValidator(new UserConfigValidator());
    }
}

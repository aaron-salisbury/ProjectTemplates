﻿using System;

namespace $safeprojectname$.Modules.Sample.MessageContracts
{
    public record GuidGenerated
    {
        public required string UUID { get; init; }
    }
}

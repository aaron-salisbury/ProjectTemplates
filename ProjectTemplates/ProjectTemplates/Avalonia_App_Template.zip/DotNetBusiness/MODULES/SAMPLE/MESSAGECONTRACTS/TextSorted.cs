﻿using System;

namespace $safeprojectname$.Modules.Sample.MessageContracts
{
    public record TextSorted
    {
        public required string? SortedText { get; init; }
    }
}

﻿using $safeprojectname$.Modules.Sample.DTOs;
using $ext_safeprojectname$.Data.Entities.Sample;
using Riok.Mapperly.Abstractions;

namespace $safeprojectname$.Modules.Sample
{
    [Mapper]
    internal partial class SampleMapper
    {
        internal partial TTarget MapToDto<TTarget>(object source);

        private partial FlatColorDto MapToDto(FlatColor source);
    }
}

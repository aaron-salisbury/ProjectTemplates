﻿using $safeprojectname$.Modules.Sample.DTOs;
using static $safeprojectname$.Modules.Sample.DomainServices.LineSorter;

namespace $safeprojectname$.Modules.Sample.ApplicationServices
{
    public interface ISampleToolsService
    {
        IEnumerable<FlatColorDto> GetFlatColors();

        Task InitializeLineSortingAsync(SortTypes _selectedSortType, string? textToSort);

        Task InitializeGUIDGenerationAsync(bool shouldCapitalize = true);
    }
}

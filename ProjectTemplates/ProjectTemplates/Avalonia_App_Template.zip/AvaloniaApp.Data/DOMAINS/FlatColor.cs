﻿using System;

namespace $safeprojectname$.Domains
{
    [Serializable]
    public class FlatColor
    {
        public string Name { get; set; } = null!;
        public string Hex { get; set; } = null!;
    }
}

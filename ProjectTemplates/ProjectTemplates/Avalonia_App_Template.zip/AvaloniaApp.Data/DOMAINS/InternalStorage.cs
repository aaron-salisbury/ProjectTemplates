﻿using System;

namespace $safeprojectname$.Domains
{
    [Serializable]
    internal class InternalStorage
    {
        public string UserStorageDirectory { get; set; } = null!;
    }
}

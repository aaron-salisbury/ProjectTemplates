﻿using System;

namespace $safeprojectname$.Base
{
    public class LoggableObject
    {
        public static NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
    }
}

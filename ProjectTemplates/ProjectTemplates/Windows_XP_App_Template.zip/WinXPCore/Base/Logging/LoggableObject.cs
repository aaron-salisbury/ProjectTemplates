﻿using System;

namespace $safeprojectname$.Base.Logging
{
    public class LoggableObject
    {
        public static NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
    }
}

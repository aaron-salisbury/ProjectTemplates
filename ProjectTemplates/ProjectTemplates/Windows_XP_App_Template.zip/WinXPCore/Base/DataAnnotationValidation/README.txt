﻿All these C# files in DataAnnotationValidation could be deleted if you update the library to target .Net Framework 4.0 or higher.

These are copied from the System.ComponentModel.DataAnnotations namespace to act as a shim while targeting .Net Framework 3.5.

I'm targeting 3.5 because I want this template to support legacy Windows XP instances and "Windows XP Home Reduced Media Edition" only supported up to .NET 3.5.
﻿using MetroFramework.Forms;
using $safeprojectname$.Base;

namespace $safeprojectname$.Forms
{
    public partial class BaseForm : MetroForm
    {
        public BaseForm()
        {
            InitializeComponent();

            AppearanceManager.LoadBaseSettings(this);
        }
    }
}

﻿using $safeprojectname$.Properties;

namespace $safeprojectname$.ViewModels
{
    public class IntroductionViewModel : BaseViewModel
    {
        public string Title
        {
            get => Settings.Default.ApplicationFriendlyName;
        }
    }
}

﻿using System.Windows.Controls;

namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for SuccessModal.xaml
    /// </summary>
    public partial class SuccessModal : UserControl
    {
        public SuccessModal()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace $safeprojectname$.Views.SampleTools
{
    /// <summary>
    /// Interaction logic for UUIDGenerator.xaml
    /// </summary>
    public partial class UUIDGenerator : UserControl
    {
        public UUIDGenerator()
        {
            InitializeComponent();
        }
    }
}

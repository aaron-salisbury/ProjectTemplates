﻿using System.Windows.Controls;

namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for Log.xaml
    /// </summary>
    public partial class Log : UserControl
    {
        public Log()
        {
            InitializeComponent();
        }
    }
}

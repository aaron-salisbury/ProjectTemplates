﻿using System.Windows.Controls;

namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for Introduction.xaml
    /// </summary>
    public partial class Introduction : UserControl
    {
        public Introduction()
        {
            InitializeComponent();
        }
    }
}

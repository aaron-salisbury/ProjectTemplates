﻿using System;

namespace $safeprojectname$.Base
{
    public class NavigationMessage
    {
        public string TargetPage { get; set; }
    }
}

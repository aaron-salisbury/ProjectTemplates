﻿using System;

namespace $safeprojectname$.SampleTools
{
    public class FlatColor
    {
        public string Name { get; set; }

        public string Hex { get; set; }
    }
}

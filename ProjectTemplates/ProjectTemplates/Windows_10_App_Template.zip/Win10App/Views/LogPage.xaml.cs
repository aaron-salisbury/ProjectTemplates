﻿using $safeprojectname$.ViewModels;
using Windows.UI.Xaml.Controls;

namespace $safeprojectname$.Views
{
    public sealed partial class LogPage : Page
    {
        public LogPage()
        {
            InitializeComponent();
            DataContext = ViewModelLocator.Current.LogViewModel;
        }
    }
}

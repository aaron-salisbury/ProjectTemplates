﻿using $safeprojectname$.ViewModels;
using Windows.UI.Xaml.Controls;

namespace $safeprojectname$.Views
{
    public sealed partial class LogPage : Page
    {
        public LogViewModel ViewModel { get; } = new LogViewModel();

        public LogPage()
        {
            InitializeComponent();
            DataContext = ViewModel;
        }
    }
}

﻿using Windows.UI.Xaml.Controls;

namespace $safeprojectname$.Views
{
    public sealed partial class IntroductionPage : Page
    {
        public IntroductionPage()
        {
            this.InitializeComponent();
        }
    }
}

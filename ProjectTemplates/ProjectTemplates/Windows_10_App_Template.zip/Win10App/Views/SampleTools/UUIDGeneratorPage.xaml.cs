﻿using $safeprojectname$.ViewModels;
using Windows.UI.Xaml.Controls;

namespace $safeprojectname$.Views
{
    public sealed partial class UUIDGeneratorPage : Page
    {
        public UUIDGeneratorPage()
        {
            InitializeComponent();
            DataContext = ViewModelLocator.Current.UUIDGeneratorViewModel;
        }
    }
}

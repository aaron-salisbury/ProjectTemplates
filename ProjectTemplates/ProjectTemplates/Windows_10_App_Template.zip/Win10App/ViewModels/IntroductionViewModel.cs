﻿using GalaSoft.MvvmLight;

namespace $safeprojectname$.ViewModels
{
    public class IntroductionViewModel : ViewModelBase
    {
    }
}

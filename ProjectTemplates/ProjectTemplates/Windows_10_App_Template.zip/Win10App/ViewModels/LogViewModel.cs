﻿using System;

namespace $safeprojectname$.ViewModels
{
    public class LogViewModel : BaseViewModel
    {
    }
}

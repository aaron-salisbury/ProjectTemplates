﻿using $ext_safeprojectname$.Core.Base;

namespace $safeprojectname$.ViewModels
{
    public class ShellViewModel : BaseNavigableViewModel
    {
        public AppLogger AppLogger { get; set; }

        public ShellViewModel()
        {
            AppLogger = new AppLogger();
        }
    }
}
